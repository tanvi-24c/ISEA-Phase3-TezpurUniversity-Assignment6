# Assignment 8 – Application Optimization, Scalability and Reliability

**Name:** Tanvi Chaudhari
**Roll No:** 5130108

## Overview
This project builds directly on Assignment 7's secure multi-client TCP chat
application. The wire protocol (`LOGIN|`, `MSG|`, `LOGOUT`, `PING`,
`OK|`/`ERROR|`/`SYS|`) and all Assignment 7 security features (SHA-256
password hashing, duplicate-login prevention, input validation, failed-login
protection, session/inactivity timeout) are unchanged. This assignment adds
connection management, reliability, scalability and configuration
improvements on top of that base, and measures their real impact.

## Files
| File | Purpose |
|---|---|
| `server.py` | Optimized server: bounded thread pool, watchdog sweep, graceful shutdown, config-driven |
| `client_gui.py` | Optimized Tkinter client: auto-reconnect, heartbeat, config-driven |
| `config.json` | All previously hardcoded parameters (Task 4) |
| `generate_users.py` / `users.csv` | Unchanged from Assignment 7 |
| `performance_test.py` | Headless load-test harness used to produce `performance_results.csv` |
| `generate_graphs.py` | Produces the graphs in `graphs/` from `performance_results.csv` |
| `performance_results.csv` | Real measured results, baseline vs optimized, at 5/8/10 clients |
| `graphs/` | Delay, throughput, CPU, memory and scaling comparison charts |
| `screenshots/` | Screenshots captured from the actual running application |
| `report.pdf` | Full assignment report (sections 6–15 per the brief) |
| `security_log.txt` | Sample log from the verification run described in the report |

## How to Run

### 1. Set up the network (Mininet)
```bash
sudo mn --topo single,11
mininet> pingall
```

### 2. Create user accounts (only if users.csv is not already present)
```bash
python3 generate_users.py
```

### 3. Start the server
```bash
python3 server.py
```
Reads all settings from `config.json`. Listens on the configured host/port
(default `0.0.0.0:5000`).

### 4. Start one or more clients
```bash
python3 client_gui.py
```
Set `client.host` in `config.json` to the server's Mininet IP (default
`10.0.0.1`) before running across hosts.

### 5. Reproduce the performance comparison
```bash
# against the Assignment 7 baseline server, running separately:
python3 performance_test.py --host <ip> --port 5000 --clients 5  --messages 20 --label "Assignment 7 (Baseline)" --server-pid <pid>
python3 performance_test.py --host <ip> --port 5000 --clients 8  --messages 20 --label "Assignment 7 (Baseline)" --server-pid <pid>
python3 performance_test.py --host <ip> --port 5000 --clients 10 --messages 20 --label "Assignment 7 (Baseline)" --server-pid <pid>

# against this Assignment 8 server:
python3 performance_test.py --host <ip> --port 5000 --clients 5  --messages 20 --label "Assignment 8 (Optimized)" --server-pid <pid>
python3 performance_test.py --host <ip> --port 5000 --clients 8  --messages 20 --label "Assignment 8 (Optimized)" --server-pid <pid>
python3 performance_test.py --host <ip> --port 5000 --clients 10 --messages 20 --label "Assignment 8 (Optimized)" --server-pid <pid>

python3 generate_graphs.py
```
`--server-pid` is optional; if omitted, CPU/memory columns are recorded as 0
but delay/throughput are still measured correctly.

## Optimizations Implemented (map to rubric)
1. **Connection Management** – watchdog sweep thread, SO_KEEPALIVE, guaranteed
   resource cleanup in a single `finally` path, specific error messages.
2. **Reliability Enhancement** – automatic client reconnection with
   exponential backoff and re-login, heartbeat PING, graceful SIGINT/SIGTERM
   shutdown that notifies clients before closing, hardened exception handling.
3. **Scalability Enhancement** – bounded `ThreadPoolExecutor` replacing
   unbounded thread-per-client, larger configurable listen backlog,
   `TCP_NODELAY`, consistent locking. Verified with 5/8/10 concurrent clients,
   zero errors.
4. **Configuration Management** – every hardcoded value moved to
   `config.json`.
5. **Performance Evaluation** – see `performance_results.csv` and `graphs/`,
   generated from real runs of both the Assignment 7 and Assignment 8 servers.

## Important note on test environment
The performance numbers in this repository were measured by actually running
both server versions and a real headless client over TCP loopback, because a
live Mininet + Wireshark environment was not available while this package was
assembled. The code itself is unchanged and ready to run on the Mininet
topology specified in the brief; re-running the commands in "Reproduce the
performance comparison" above unmodified on Mininet is recommended if
Mininet-specific absolute timing numbers are required for submission.

## Still required before submission (not included here)
- **Wireshark capture** on the actual Mininet topology (see `report.pdf`,
  Section 13, for the exact capture procedure and what to verify).
- **Screenshots from your own Mininet run**, if your instructor requires them
  to be taken on Mininet specifically rather than the loopback demonstration
  screenshots included here.
- **`handwritten_reflection.pdf`** – Task 8 requires the 5 reflection
  questions to be answered *by hand* and scanned. This cannot be produced on
  your behalf; please handwrite, scan, and add it to this folder before
  zipping up your submission.
- **GitHub update** (Task 7) – push this folder to your repository using the
  `ISEAPhase3-TezpurUniversity-...` naming convention.
