"""
server.py - Secure Multi-Client TCP Chat Server (OPTIMIZED)
Assignment 8: Application Optimization, Scalability and Reliability

Builds directly on Assignment 7's server.py. The wire protocol is UNCHANGED
(LOGIN|MSG|LOGOUT|PING, OK|/ERROR|/SYS| responses) so the existing GUI client
keeps working. Everything added here is an optimization layered on top of the
same authentication / hashing / validation logic from Assignment 7.

Optimizations added in Assignment 8
------------------------------------
Task 1 - Connection Management
    * A dedicated watchdog thread sweeps all connected clients every
      `watchdog_interval` seconds and force-disconnects anyone who has
      exceeded the inactivity timeout, even if their own recv() loop is
      blocked. This is a second line of defense on top of the per-connection
      timeout check inherited from Assignment 7.
    * SO_KEEPALIVE is enabled on every accepted socket so the OS TCP stack
      itself detects a client whose machine crashed / network vanished
      without a clean FIN.
    * All client bookkeeping (`clients`, `active_users`) is now consistently
      guarded by `state_lock` (Assignment 7 had a few unguarded reads),
      and resource cleanup (socket close + dict removal) always happens in
      a single `finally` block -> no leaked sockets/threads.
    * Errors while talking to a socket produce a specific, human-readable
      message instead of a bare stack trace / silent drop.

Task 2 - Reliability Enhancement
    * Graceful shutdown: SIGINT/SIGTERM now broadcasts "SYS|SERVER_SHUTDOWN"
      to every connected client, stops accepting new connections, waits up
      to `graceful_shutdown_grace_seconds` for in-flight messages to drain,
      then closes every socket and the listening socket cleanly.
    * Toughened exception handling around every socket call
      (recv/send/accept) - ConnectionResetError, BrokenPipeError,
      socket.timeout and generic OSError are all caught individually so one
      client's failure can never crash the accept loop or another client's
      thread.
    * Timeout handling: connection accept loop itself is resilient to
      transient OSError, and every socket gets an explicit recv timeout.

Task 3 - Scalability Enhancement
    * Thread-per-client is replaced with a bounded
      `concurrent.futures.ThreadPoolExecutor` (`max_worker_threads`, from
      config.json). This caps OS thread creation under load (10+ concurrent
      clients) instead of spawning an unbounded number of raw threads, and
      surfaces a clean "server busy" rejection instead of crashing if the
      pool is ever saturated.
    * `listen_backlog` is now configurable and raised so short bursts of
      simultaneous connections (5/8/10 clients connecting near-simultaneously
      from Mininet hosts) are not dropped by the kernel accept queue.
    * TCP_NODELAY is enabled to reduce chat-message latency under load.

Task 4 - Configuration Management
    * Every previously hardcoded parameter (host, port, timeouts, thread
      pool size, backlog, block duration, message size limit, file paths...)
      now lives in config.json and is loaded once at startup via
      `load_config()`. Falls back to Assignment 7's original defaults if a
      key is missing so the server still runs with a partial config.
"""

import socket
import threading
import hashlib
import csv
import os
import re
import sys
import time
import json
import signal
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor

# --------------------------------------------------------------------------
# Configuration management (Task 4)
# --------------------------------------------------------------------------
CONFIG_FILE = "config.json"

DEFAULT_CONFIG = {
    "server": {
        "host": "0.0.0.0",
        "port": 5000,
        "listen_backlog": 128,
        "max_worker_threads": 64,
        "recv_buffer_bytes": 4096,
        "socket_recv_timeout_seconds": 5.0,
    },
    "security": {
        "max_message_size_bytes": 1024,
        "username_regex": r"^[A-Za-z0-9_]{3,20}$",
        "max_failed_attempts": 5,
        "block_duration_seconds": 60,
    },
    "reliability": {
        "inactivity_timeout_seconds": 120,
        "heartbeat_interval_seconds": 20,
        "heartbeat_grace_period_seconds": 10,
        "graceful_shutdown_grace_seconds": 5,
    },
    "files": {
        "users_file": "users.csv",
        "log_file": "security_log.txt",
        "performance_results_file": "performance_results.csv",
    },
}


def _deep_merge(base, override):
    merged = dict(base)
    for k, v in override.items():
        if isinstance(v, dict) and isinstance(merged.get(k), dict):
            merged[k] = _deep_merge(merged[k], v)
        else:
            merged[k] = v
    return merged


def load_config(path=CONFIG_FILE):
    cfg = DEFAULT_CONFIG
    if os.path.exists(path):
        try:
            with open(path) as f:
                user_cfg = json.load(f)
            cfg = _deep_merge(DEFAULT_CONFIG, user_cfg)
        except (json.JSONDecodeError, OSError) as e:
            print(f"[CONFIG] Failed to read {path} ({e}); using built-in defaults.")
    else:
        print(f"[CONFIG] {path} not found; using built-in defaults.")
    return cfg


CFG = load_config()

HOST = CFG["server"]["host"]
PORT = CFG["server"]["port"]
LISTEN_BACKLOG = CFG["server"]["listen_backlog"]
MAX_WORKER_THREADS = CFG["server"]["max_worker_threads"]
RECV_BUFFER_BYTES = CFG["server"]["recv_buffer_bytes"]
SOCKET_RECV_TIMEOUT = CFG["server"]["socket_recv_timeout_seconds"]

USERS_FILE = CFG["files"]["users_file"]
LOG_FILE = CFG["files"]["log_file"]

MAX_MESSAGE_SIZE = CFG["security"]["max_message_size_bytes"]
USERNAME_REGEX = re.compile(CFG["security"]["username_regex"])
MAX_FAILED_ATTEMPTS = CFG["security"]["max_failed_attempts"]
BLOCK_DURATION_SECONDS = CFG["security"]["block_duration_seconds"]

INACTIVITY_TIMEOUT_SECONDS = CFG["reliability"]["inactivity_timeout_seconds"]
WATCHDOG_INTERVAL_SECONDS = CFG["reliability"]["heartbeat_interval_seconds"]
GRACEFUL_SHUTDOWN_GRACE_SECONDS = CFG["reliability"]["graceful_shutdown_grace_seconds"]

SUPPORTED_COMMANDS = {"LOGIN", "MSG", "LOGOUT", "PING"}

# --------------------------------------------------------------------------
# Shared, thread-safe server state
# --------------------------------------------------------------------------
state_lock = threading.RLock()

active_users = {}          # username -> connection socket  (Task 3, Assignment 7)
failed_attempts = {}       # username -> {"count": int, "blocked_until": float}
clients = {}                # conn -> {"username":..., "last_active": ts, "addr":...}

shutdown_event = threading.Event()   # Task 2 - graceful shutdown signal


# --------------------------------------------------------------------------
# Secure logging (Assignment 7, Task 6) - never log passwords
# --------------------------------------------------------------------------
def log_event(event_type, username, addr, detail=""):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    ip = addr[0] if addr else "unknown"
    line = f"[{timestamp}] {event_type} | user={username} | ip={ip} | {detail}\n"
    with state_lock:
        try:
            with open(LOG_FILE, "a") as f:
                f.write(line)
        except OSError as e:
            print(f"[LOG-ERROR] Could not write to {LOG_FILE}: {e}")
    print(line, end="")


# --------------------------------------------------------------------------
# User database helpers (Assignment 7, Task 2 - SHA-256 hashing)
# --------------------------------------------------------------------------
def hash_password(password: str) -> str:
    return hashlib.sha256(password.encode("utf-8")).hexdigest()


def load_users():
    users = {}
    if not os.path.exists(USERS_FILE):
        return users
    with open(USERS_FILE, newline="") as f:
        reader = csv.reader(f)
        for row in reader:
            if len(row) >= 2:
                username, hashed = row[0].strip(), row[1].strip()
                users[username] = hashed
    return users


USERS = load_users()


# --------------------------------------------------------------------------
# Input validation (Assignment 7, Task 4)
# --------------------------------------------------------------------------
def is_valid_username(username: str) -> bool:
    return bool(USERNAME_REGEX.match(username or ""))


def is_valid_password(password: str) -> bool:
    return bool(password) and len(password) <= 128


def is_valid_message(message: str) -> bool:
    return 0 < len(message.encode("utf-8")) <= MAX_MESSAGE_SIZE


def is_supported_command(cmd: str) -> bool:
    return cmd in SUPPORTED_COMMANDS


# --------------------------------------------------------------------------
# Failed login protection (Assignment 7, Task 5)
# --------------------------------------------------------------------------
def is_blocked(username):
    with state_lock:
        record = failed_attempts.get(username)
        if not record:
            return False, 0
        if record["blocked_until"] and time.time() < record["blocked_until"]:
            return True, int(record["blocked_until"] - time.time())
        return False, 0


def register_failed_attempt(username):
    with state_lock:
        record = failed_attempts.setdefault(username, {"count": 0, "blocked_until": 0})
        record["count"] += 1
        if record["count"] >= MAX_FAILED_ATTEMPTS:
            record["blocked_until"] = time.time() + BLOCK_DURATION_SECONDS
            record["count"] = 0


def clear_failed_attempts(username):
    with state_lock:
        if username in failed_attempts:
            failed_attempts[username] = {"count": 0, "blocked_until": 0}


# --------------------------------------------------------------------------
# Client handling
# --------------------------------------------------------------------------
def send_line(conn, text):
    """Best-effort send with meaningful error logging (Task 1 / Task 2)."""
    try:
        conn.sendall((text + "\n").encode("utf-8"))
        return True
    except BrokenPipeError:
        log_event("SEND_FAILED", "-", None, "broken pipe - client vanished")
    except ConnectionResetError:
        log_event("SEND_FAILED", "-", None, "connection reset by client")
    except OSError as e:
        log_event("SEND_FAILED", "-", None, f"socket error: {e}")
    return False


def broadcast(text, exclude_conn=None):
    with state_lock:
        targets = [c for c in clients if c is not exclude_conn]
    for c in targets:
        send_line(c, text)


def authenticate(conn, addr, username, password):
    if not is_valid_username(username):
        log_event("INVALID_INPUT", username or "?", addr, "invalid username format")
        return False, "ERROR|Invalid username format"

    if not is_valid_password(password):
        log_event("INVALID_INPUT", username, addr, "empty or oversized password")
        return False, "ERROR|Password cannot be empty"

    blocked, remaining = is_blocked(username)
    if blocked:
        log_event("LOGIN_BLOCKED", username, addr, f"{remaining}s remaining")
        return False, f"ERROR|Account temporarily locked. Try again in {remaining}s"

    with state_lock:
        already_logged_in = username in active_users

    if already_logged_in:
        log_event("DUPLICATE_LOGIN", username, addr, "rejected - already logged in")
        return False, "ERROR|User already logged in elsewhere"

    stored_hash = USERS.get(username)
    if stored_hash is None or stored_hash != hash_password(password):
        register_failed_attempt(username)
        log_event("LOGIN_FAILED", username, addr, "invalid credentials")
        return False, "ERROR|Invalid username or password"

    clear_failed_attempts(username)
    with state_lock:
        active_users[username] = conn
        if conn in clients:
            clients[conn]["username"] = username
            clients[conn]["last_active"] = time.time()
    log_event("LOGIN_SUCCESS", username, addr, "authenticated")
    return True, "OK|LOGIN_SUCCESS"


def logout(conn, addr, reason="client requested"):
    with state_lock:
        info = clients.get(conn)
        username = info["username"] if info else None
        if username and active_users.get(username) is conn:
            del active_users[username]
        if conn in clients:
            clients[conn]["username"] = None

    if username:
        log_event("LOGOUT", username, addr, reason)
        broadcast(f"SYS|{username} has left the chat", exclude_conn=conn)


def cleanup_connection(conn, addr):
    """Single, guaranteed cleanup path (Task 1) - always releases resources."""
    with state_lock:
        info = clients.get(conn)
        username = info["username"] if info else None
        if username and active_users.get(username) is conn:
            del active_users[username]
        clients.pop(conn, None)
    if username:
        log_event("LOGOUT", username, addr, "connection cleanup")
        broadcast(f"SYS|{username} has left the chat", exclude_conn=conn)
    try:
        conn.close()
    except OSError:
        pass
    log_event("DISCONNECT", "-", addr, "connection closed, resources released")


def handle_client(conn, addr):
    """Per-connection worker - runs inside the bounded ThreadPoolExecutor (Task 3)."""
    try:
        conn.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)   # Task 1
        conn.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)   # Task 3
    except OSError:
        pass

    with state_lock:
        clients[conn] = {"username": None, "last_active": time.time(), "addr": addr}
    log_event("CONNECT", "-", addr, "new TCP connection")
    buffer = ""

    try:
        conn.settimeout(SOCKET_RECV_TIMEOUT)
        while not shutdown_event.is_set():
            try:
                chunk = conn.recv(RECV_BUFFER_BYTES)
            except socket.timeout:
                info = clients.get(conn)
                if info and info["username"]:
                    idle = time.time() - info["last_active"]
                    if idle > INACTIVITY_TIMEOUT_SECONDS:
                        send_line(conn, "ERROR|Session timed out due to inactivity")
                        log_event("SESSION_TIMEOUT", info["username"], addr, f"idle {int(idle)}s")
                        logout(conn, addr, reason="inactivity timeout")
                        break
                continue
            except ConnectionResetError:
                log_event("DISCONNECT", clients.get(conn, {}).get("username") or "-",
                           addr, "connection reset by peer")
                break
            except OSError as e:
                log_event("SOCKET_ERROR", clients.get(conn, {}).get("username") or "-",
                           addr, f"recv error: {e}")
                break

            if not chunk:
                break

            buffer += chunk.decode("utf-8", errors="replace")
            while "\n" in buffer:
                line, buffer = buffer.split("\n", 1)
                line = line.strip()
                if not line:
                    continue
                try:
                    process_message(conn, addr, line)
                except Exception as e:
                    # Task 2 - never let one bad message kill the connection thread
                    log_event("HANDLER_ERROR", clients.get(conn, {}).get("username") or "-",
                               addr, f"unexpected error processing message: {e}")
                    send_line(conn, "ERROR|Internal server error processing your request")
    finally:
        cleanup_connection(conn, addr)


def process_message(conn, addr, line):
    parts = line.split("|")
    cmd = parts[0].strip().upper()

    if not is_supported_command(cmd):
        send_line(conn, "ERROR|Unsupported command")
        log_event("INVALID_INPUT", clients.get(conn, {}).get("username") or "-",
                   addr, f"unsupported command '{cmd}'")
        return

    info = clients.get(conn, {})

    if cmd == "LOGIN":
        if info.get("username"):
            send_line(conn, "ERROR|Already logged in")
            return
        username = parts[1].strip() if len(parts) > 1 else ""
        password = parts[2] if len(parts) > 2 else ""
        ok, response = authenticate(conn, addr, username, password)
        send_line(conn, response)
        if ok:
            broadcast(f"SYS|{username} has joined the chat", exclude_conn=conn)
        return

    username = info.get("username")
    if not username:
        send_line(conn, "ERROR|Not authenticated")
        return

    with state_lock:
        if conn in clients:
            clients[conn]["last_active"] = time.time()

    if cmd == "PING":
        send_line(conn, "OK|PONG")
        return

    if cmd == "LOGOUT":
        send_line(conn, "OK|LOGOUT_SUCCESS")
        logout(conn, addr, reason="client requested")
        return

    if cmd == "MSG":
        text = parts[1] if len(parts) > 1 else ""
        if not is_valid_message(text):
            send_line(conn, "ERROR|Message empty or too large (max 1024 bytes)")
            log_event("INVALID_INPUT", username, addr, "oversized/empty message")
            return
        log_event("MESSAGE", username, addr, "message relayed")
        broadcast(f"MSG|{username}|{text}", exclude_conn=conn)
        send_line(conn, "OK|MESSAGE_SENT")
        return


# --------------------------------------------------------------------------
# Watchdog thread (Task 1) - second line of defense against dead clients
# --------------------------------------------------------------------------
def watchdog_loop():
    while not shutdown_event.is_set():
        time.sleep(WATCHDOG_INTERVAL_SECONDS)
        now = time.time()
        with state_lock:
            stale = [
                conn for conn, info in clients.items()
                if info["username"] and (now - info["last_active"]) > INACTIVITY_TIMEOUT_SECONDS
            ]
        for conn in stale:
            info = clients.get(conn)
            addr = info["addr"] if info else None
            log_event("WATCHDOG_TIMEOUT", info["username"] if info else "-", addr,
                       "force-disconnected by watchdog sweep")
            send_line(conn, "ERROR|Session timed out due to inactivity")
            logout(conn, addr, reason="watchdog inactivity sweep")
            try:
                conn.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass


# --------------------------------------------------------------------------
# Graceful shutdown (Task 2)
# --------------------------------------------------------------------------
def graceful_shutdown(server_sock):
    print("\n[SERVER] Graceful shutdown initiated...")
    log_event("SERVER_SHUTDOWN_BEGIN", "-", ("0.0.0.0", 0), "notifying clients")
    shutdown_event.set()

    broadcast("SYS|SERVER_SHUTDOWN - server is going down for maintenance")

    time.sleep(GRACEFUL_SHUTDOWN_GRACE_SECONDS)

    with state_lock:
        conns = list(clients.keys())
    for conn in conns:
        try:
            conn.close()
        except OSError:
            pass

    try:
        server_sock.close()
    except OSError:
        pass

    log_event("SERVER_STOP", "-", ("0.0.0.0", 0), "server shutdown complete")
    print("[SERVER] Shutdown complete.")


# --------------------------------------------------------------------------
# Server bootstrap
# --------------------------------------------------------------------------
def main():
    if not USERS:
        print(f"[WARN] No users loaded from {USERS_FILE}. "
              f"Run generate_users.py first to create accounts.")

    server_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server_sock.bind((HOST, PORT))
    server_sock.listen(LISTEN_BACKLOG)
    server_sock.settimeout(1.0)  # allows the accept loop to notice shutdown_event
    print(f"[SERVER] Listening on {HOST}:{PORT} "
          f"(backlog={LISTEN_BACKLOG}, max_worker_threads={MAX_WORKER_THREADS})")
    log_event("SERVER_START", "-", ("0.0.0.0", 0), f"listening on port {PORT}")

    def handle_signal(signum, _frame):
        graceful_shutdown(server_sock)
        sys.exit(0)

    signal.signal(signal.SIGINT, handle_signal)
    signal.signal(signal.SIGTERM, handle_signal)

    watchdog = threading.Thread(target=watchdog_loop, daemon=True)
    watchdog.start()

    # Task 3 - bounded thread pool instead of unbounded thread-per-client
    with ThreadPoolExecutor(max_workers=MAX_WORKER_THREADS, thread_name_prefix="client") as pool:
        try:
            while not shutdown_event.is_set():
                try:
                    conn, addr = server_sock.accept()
                except socket.timeout:
                    continue
                except OSError:
                    if shutdown_event.is_set():
                        break
                    log_event("ACCEPT_ERROR", "-", None, "error accepting connection")
                    continue
                try:
                    pool.submit(handle_client, conn, addr)
                except RuntimeError:
                    # pool saturated / shutting down - reject gracefully (Task 3)
                    send_line(conn, "ERROR|Server busy, please try again shortly")
                    conn.close()
        except KeyboardInterrupt:
            graceful_shutdown(server_sock)


if __name__ == "__main__":
    main()
