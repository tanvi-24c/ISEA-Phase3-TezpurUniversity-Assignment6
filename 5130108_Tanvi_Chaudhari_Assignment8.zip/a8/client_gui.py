"""
client_gui.py - Tkinter GUI client for the Secure Multi-Client TCP Chat (OPTIMIZED)
Assignment 8: Application Optimization, Scalability and Reliability

Builds on Assignment 7's client_gui.py. The wire protocol talking to
server.py is UNCHANGED. Everything below is a reliability / maintainability
optimization on top of the same SecureChatClient / ChatApp structure.

Optimizations added in Assignment 8
------------------------------------
Task 2 - Reliability Enhancement
    * Automatic reconnection: if the socket drops unexpectedly while the
      user is logged in, the client detects it, shows a "reconnecting..."
      banner, and retries with exponential backoff (config-driven) up to
      `max_reconnect_attempts`. On reconnect it automatically re-sends the
      cached LOGIN so the user does not have to retype credentials for a
      transient network blip (credentials are kept in memory only, never
      written to disk).
    * Heartbeat: a background thread sends periodic PING so both the client
      and server notice a half-open connection quickly instead of waiting
      for a full TCP timeout.
    * Connect timeout: the socket now has an explicit connect timeout
      instead of blocking forever if the server/host is unreachable.
    * Much more specific exception handling around every socket operation,
      each surfaced to the user as a clear, actionable message instead of a
      raw Python traceback / silent failure.
    * Graceful handling of `SYS|SERVER_SHUTDOWN` - the client tells the user
      the server is shutting down instead of just erroring out.

Task 4 - Configuration Management
    * host/port/timeouts/reconnect policy are now loaded from config.json
      instead of being hardcoded constants.
"""

import socket
import threading
import time
import json
import os
import tkinter as tk
from tkinter import ttk, messagebox

CONFIG_FILE = "config.json"

DEFAULT_CLIENT_CONFIG = {
    "host": "10.0.0.1",
    "port": 5000,
    "connect_timeout_seconds": 5.0,
    "auto_reconnect": True,
    "max_reconnect_attempts": 8,
    "reconnect_initial_delay_seconds": 1.0,
    "reconnect_max_delay_seconds": 20.0,
    "heartbeat_interval_seconds": 15,
}


def load_client_config(path=CONFIG_FILE):
    cfg = dict(DEFAULT_CLIENT_CONFIG)
    if os.path.exists(path):
        try:
            with open(path) as f:
                full = json.load(f)
            cfg.update(full.get("client", {}))
        except (json.JSONDecodeError, OSError) as e:
            print(f"[CONFIG] Failed to read {path} ({e}); using built-in client defaults.")
    return cfg


CFG = load_client_config()
HOST = CFG["host"]
PORT = CFG["port"]
MAX_MESSAGE_SIZE = 1024


# --------------------------------------------------------------------------
# Networking layer (no GUI dependencies)
# --------------------------------------------------------------------------
class SecureChatClient:
    def __init__(self, host=HOST, port=PORT):
        self.host = host
        self.port = port
        self.sock = None
        self.connected = False
        self.on_message = None       # callback(text) set by GUI
        self.on_disconnect = None    # callback() set by GUI - unexpected drop
        self._recv_thread = None
        self._heartbeat_thread = None
        self._stop_heartbeat = threading.Event()

    def connect(self):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.settimeout(CFG["connect_timeout_seconds"])
        self.sock.connect((self.host, self.port))
        self.sock.settimeout(None)
        try:
            self.sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        except OSError:
            pass
        self.connected = True
        self._stop_heartbeat.clear()
        self._recv_thread = threading.Thread(target=self._listen, daemon=True)
        self._recv_thread.start()
        self._heartbeat_thread = threading.Thread(target=self._heartbeat_loop, daemon=True)
        self._heartbeat_thread.start()

    def _heartbeat_loop(self):
        """Task 2 - periodic PING so half-open connections are noticed quickly."""
        interval = CFG["heartbeat_interval_seconds"]
        while self.connected and not self._stop_heartbeat.wait(interval):
            try:
                self._send("PING")
            except OSError:
                break

    def _listen(self):
        buffer = ""
        disconnect_was_clean = False
        while self.connected:
            try:
                chunk = self.sock.recv(4096)
            except (ConnectionResetError, OSError):
                break
            if not chunk:
                break
            buffer += chunk.decode("utf-8", errors="replace")
            while "\n" in buffer:
                line, buffer = buffer.split("\n", 1)
                line = line.strip()
                if line and self.on_message:
                    self.on_message(line)
        was_connected = self.connected
        self.connected = False
        self._stop_heartbeat.set()
        if was_connected and not disconnect_was_clean and self.on_disconnect:
            self.on_disconnect()

    def _send(self, text):
        if not self.sock:
            raise OSError("not connected")
        self.sock.sendall((text + "\n").encode("utf-8"))

    def login(self, username, password):
        self._send(f"LOGIN|{username}|{password}")

    def send_message(self, text):
        self._send(f"MSG|{text}")

    def logout(self):
        try:
            self._send("LOGOUT")
        except OSError:
            pass

    def close(self):
        self.connected = False
        self._stop_heartbeat.set()
        if self.sock:
            try:
                self.sock.close()
            except OSError:
                pass


# --------------------------------------------------------------------------
# GUI layer
# --------------------------------------------------------------------------
class ChatApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Secure TCP Chat (Optimized - Assignment 8)")
        self.root.geometry("480x580")
        self.client = SecureChatClient()
        self.username = None
        self.pending_username = None
        self.pending_password = None   # kept in memory only, for auto reconnect+relogin
        self.reconnect_attempts = 0
        self.reconnecting = False

        self.login_frame = None
        self.chat_frame = None
        self.banner_label = None

        self.build_login_frame()

    # ---------------- Login screen ----------------
    def build_login_frame(self):
        self.login_frame = ttk.Frame(self.root, padding=30)
        self.login_frame.pack(expand=True, fill="both")

        ttk.Label(self.login_frame, text="Secure Chat Login",
                  font=("Segoe UI", 16, "bold")).pack(pady=(0, 20))

        ttk.Label(self.login_frame, text="Username").pack(anchor="w")
        self.username_entry = ttk.Entry(self.login_frame)
        self.username_entry.pack(fill="x", pady=(0, 10))

        ttk.Label(self.login_frame, text="Password").pack(anchor="w")
        self.password_entry = ttk.Entry(self.login_frame, show="*")
        self.password_entry.pack(fill="x", pady=(0, 20))
        self.password_entry.bind("<Return>", lambda e: self.attempt_login())

        self.status_label = ttk.Label(self.login_frame, text="", foreground="red")
        self.status_label.pack(pady=(0, 10))

        ttk.Button(self.login_frame, text="Login",
                   command=self.attempt_login).pack(fill="x")

    def attempt_login(self):
        username = self.username_entry.get().strip()
        password = self.password_entry.get()

        if not username or not password:
            self.status_label.config(text="Username and password are required")
            return

        try:
            if not self.client.connected:
                self.client.connect()
        except socket.timeout:
            self.status_label.config(text=f"Connection timed out reaching {HOST}:{PORT}")
            return
        except ConnectionRefusedError:
            self.status_label.config(text="Server refused connection (is server.py running?)")
            return
        except OSError as e:
            self.status_label.config(text=f"Cannot reach server: {e}")
            return

        self.client.on_message = self.handle_server_message
        self.client.on_disconnect = self.handle_unexpected_disconnect
        self.pending_username = username
        self.pending_password = password
        try:
            self.client.login(username, password)
        except OSError as e:
            self.status_label.config(text=f"Failed to send login request: {e}")

    # ---------------- Server message handling ----------------
    def handle_server_message(self, line):
        self.root.after(0, self._process_line, line)

    def handle_unexpected_disconnect(self):
        self.root.after(0, self._on_unexpected_disconnect)

    def _on_unexpected_disconnect(self):
        if self.chat_frame is None:
            return  # was never logged in / user-initiated close already handled
        self.append_chat("[SYSTEM] Connection lost. Attempting to reconnect...")
        self._start_reconnect()

    def _start_reconnect(self):
        if self.reconnecting or not CFG["auto_reconnect"]:
            return
        self.reconnecting = True
        self.reconnect_attempts = 0
        threading.Thread(target=self._reconnect_worker, daemon=True).start()

    def _reconnect_worker(self):
        delay = CFG["reconnect_initial_delay_seconds"]
        max_delay = CFG["reconnect_max_delay_seconds"]
        max_attempts = CFG["max_reconnect_attempts"]

        while self.reconnect_attempts < max_attempts:
            self.reconnect_attempts += 1
            self.root.after(0, self.append_chat,
                             f"[SYSTEM] Reconnect attempt {self.reconnect_attempts}/{max_attempts}...")
            try:
                new_client = SecureChatClient()
                new_client.connect()
                new_client.on_message = self.handle_server_message
                new_client.on_disconnect = self.handle_unexpected_disconnect
                self.client = new_client
                self.client.login(self.pending_username, self.pending_password)
                self.reconnecting = False
                return
            except OSError:
                time.sleep(delay)
                delay = min(delay * 2, max_delay)

        self.reconnecting = False
        self.root.after(0, self.append_chat,
                         "[SYSTEM] Could not reconnect. Please log in again.")
        self.root.after(0, self.return_to_login)

    def _process_line(self, line):
        parts = line.split("|")
        tag = parts[0]

        if tag == "OK" and len(parts) > 1 and parts[1] == "LOGIN_SUCCESS":
            self.username = self.pending_username
            if self.chat_frame is None:
                self.build_chat_frame()
            else:
                self.append_chat(f"[SYSTEM] Reconnected and re-authenticated as {self.username}")
            return

        if tag == "ERROR":
            msg = parts[1] if len(parts) > 1 else "Unknown error"
            if self.chat_frame is None:
                self.status_label.config(text=msg)
            else:
                self.append_chat(f"[SYSTEM] {msg}")
                if "timed out" in msg.lower():
                    self.return_to_login()
            return

        if tag == "MSG" and len(parts) >= 3:
            self.append_chat(f"{parts[1]}: {parts[2]}")
            return

        if tag == "SYS":
            text = parts[1] if len(parts) > 1 else ""
            self.append_chat(f"[SYSTEM] {text}")
            if text.startswith("SERVER_SHUTDOWN"):
                self.append_chat("[SYSTEM] Server is shutting down for maintenance.")
            return

    # ---------------- Chat screen ----------------
    def build_chat_frame(self):
        self.login_frame.destroy()
        self.chat_frame = ttk.Frame(self.root, padding=10)
        self.chat_frame.pack(expand=True, fill="both")

        top = ttk.Frame(self.chat_frame)
        top.pack(fill="x")
        ttk.Label(top, text=f"Logged in as {self.username}",
                  font=("Segoe UI", 11, "bold")).pack(side="left")
        ttk.Button(top, text="Logout", command=self.do_logout).pack(side="right")

        self.chat_display = tk.Text(self.chat_frame, state="disabled", wrap="word")
        self.chat_display.pack(expand=True, fill="both", pady=10)

        bottom = ttk.Frame(self.chat_frame)
        bottom.pack(fill="x")
        self.message_entry = ttk.Entry(bottom)
        self.message_entry.pack(side="left", expand=True, fill="x")
        self.message_entry.bind("<Return>", lambda e: self.send_message())
        ttk.Button(bottom, text="Send", command=self.send_message).pack(side="right")

    def append_chat(self, text):
        if not self.chat_frame:
            return
        self.chat_display.config(state="normal")
        self.chat_display.insert("end", text + "\n")
        self.chat_display.config(state="disabled")
        self.chat_display.see("end")

    def send_message(self):
        text = self.message_entry.get().strip()
        if not text:
            return
        if len(text.encode("utf-8")) > MAX_MESSAGE_SIZE:
            messagebox.showerror("Message too large", "Message exceeds 1024 bytes")
            return
        try:
            self.client.send_message(text)
        except OSError as e:
            self.append_chat(f"[SYSTEM] Failed to send message: {e}")
            return
        self.message_entry.delete(0, "end")

    def do_logout(self):
        self.client.logout()
        self.client.close()
        self.return_to_login()

    def return_to_login(self):
        if self.chat_frame:
            self.chat_frame.destroy()
            self.chat_frame = None
        self.pending_password = None
        self.client = SecureChatClient()
        self.build_login_frame()


def main():
    root = tk.Tk()
    app = ChatApp(root)

    def on_close():
        try:
            app.client.close()
        except Exception:
            pass
        root.destroy()

    root.protocol("WM_DELETE_WINDOW", on_close)
    root.mainloop()


if __name__ == "__main__":
    main()
