"""
generate_graphs.py - Task 5 (Performance Evaluation)

Reads performance_results.csv (produced by performance_test.py, run against
both the Assignment 7 baseline server and the Assignment 8 optimized server)
and produces comparison graphs in graphs/.
"""

import csv
import os
import matplotlib.pyplot as plt

RESULTS_FILE = "performance_results.csv"
OUT_DIR = "graphs"

os.makedirs(OUT_DIR, exist_ok=True)

rows = []
with open(RESULTS_FILE, newline="") as f:
    reader = csv.DictReader(f)
    for row in reader:
        rows.append(row)

labels = sorted(set(r["label"] for r in rows))
client_counts = sorted(set(int(r["num_clients"]) for r in rows))

def series_for(label, field):
    by_clients = {int(r["num_clients"]): float(r[field]) for r in rows if r["label"] == label}
    return [by_clients.get(c, 0.0) for c in client_counts]

COLORS = {labels[0]: "#d95f02", labels[1] if len(labels) > 1 else "x": "#1b9e77"}


def plot_metric(field, ylabel, title, filename, annotate_fmt="{:.2f}"):
    plt.figure(figsize=(7, 4.5))
    width = 0.35
    x = range(len(client_counts))
    for i, label in enumerate(labels):
        vals = series_for(label, field)
        offset = [xi + (i - 0.5) * width for xi in x]
        bars = plt.bar(offset, vals, width=width, label=label, color=COLORS.get(label))
        for b, v in zip(bars, vals):
            plt.text(b.get_x() + b.get_width() / 2, b.get_height(), annotate_fmt.format(v),
                      ha="center", va="bottom", fontsize=8)
    plt.xticks(list(x), [f"{c} clients" for c in client_counts])
    plt.ylabel(ylabel)
    plt.title(title)
    plt.legend()
    plt.tight_layout()
    path = os.path.join(OUT_DIR, filename)
    plt.savefig(path, dpi=150)
    plt.close()
    print(f"Saved {path}")


plot_metric("avg_delay_ms", "Average delay (ms)",
            "Average Message Delay: Baseline vs Optimized", "delay_comparison.png")

plot_metric("throughput_msgs_per_sec", "Throughput (messages/sec)",
            "Throughput: Baseline vs Optimized", "throughput_comparison.png", "{:.0f}")

plot_metric("server_cpu_percent", "Server CPU usage (%)",
            "Server CPU Usage: Baseline vs Optimized", "cpu_comparison.png")

plot_metric("server_memory_mb", "Server memory (MB)",
            "Server Memory Usage: Baseline vs Optimized", "memory_comparison.png", "{:.1f}")

# Line chart: throughput scaling with client count, one line per label
plt.figure(figsize=(7, 4.5))
for label in labels:
    vals = series_for(label, "throughput_msgs_per_sec")
    plt.plot(client_counts, vals, marker="o", label=label, color=COLORS.get(label))
plt.xlabel("Concurrent clients")
plt.ylabel("Throughput (messages/sec)")
plt.title("Throughput Scaling with Concurrent Clients")
plt.xticks(client_counts)
plt.legend()
plt.grid(alpha=0.3)
plt.tight_layout()
path = os.path.join(OUT_DIR, "scalability_scaling.png")
plt.savefig(path, dpi=150)
plt.close()
print(f"Saved {path}")

print("All graphs generated in graphs/")
