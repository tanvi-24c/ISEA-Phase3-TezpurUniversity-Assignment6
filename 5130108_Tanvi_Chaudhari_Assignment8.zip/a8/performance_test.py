"""
performance_test.py - Load-testing harness for Task 5 (Performance Evaluation)

Drives the REAL server.py wire protocol (LOGIN|MSG|LOGOUT, OK|/ERROR|) with a
configurable number of concurrent headless clients, and measures:
    * average message round-trip delay (ms)
    * throughput (messages/second)
    * server-side CPU usage (%) during the run
    * server-side memory usage (MB) during the run

Results are appended as rows to performance_results.csv so the SAME script
can be pointed at the Assignment 7 baseline server and the Assignment 8
optimized server, producing a genuine before/after comparison from actual
runs (not fabricated numbers).

Usage:
    python3 performance_test.py --label "Assignment 7 (Baseline)" \
        --clients 5 --messages 20 --server-pid <pid>

    python3 performance_test.py --label "Assignment 8 (Optimized)" \
        --clients 10 --messages 20 --server-pid <pid>

If --server-pid is omitted, CPU/memory columns are recorded as 0 (the script
still measures latency/throughput correctly).
"""

import argparse
import csv
import os
import socket
import threading
import time
import statistics

try:
    import psutil
except ImportError:
    psutil = None

RESULTS_FILE = "performance_results.csv"
CSV_HEADER = [
    "timestamp", "label", "num_clients", "messages_per_client", "total_messages",
    "avg_delay_ms", "p95_delay_ms", "throughput_msgs_per_sec",
    "server_cpu_percent", "server_memory_mb", "errors",
]

# Test accounts - must exist in users.csv (see generate_users.py): tanvi/alice/bob
TEST_ACCOUNTS = [
    ("tanvi", "Tanvi@123"),
    ("alice", "Alice#456"),
    ("bob", "Bob$789"),
]


class LoadTestClient:
    """Minimal, headless re-implementation of the SecureChatClient networking
    logic (no GUI / Tkinter dependency) used purely to drive load for testing.
    Talks the exact same protocol as client_gui.py."""

    def __init__(self, host, port, username, password):
        self.host = host
        self.port = port
        self.username = username
        self.password = password
        self.sock = None
        self.connected = False
        self.latencies = []
        self.errors = 0
        self._buffer = ""
        self._lock = threading.Lock()
        self._pending_send_time = None
        self._login_event = threading.Event()
        self._login_ok = False
        self._ack_event = threading.Event()

    def connect_and_login(self, timeout=5.0):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.settimeout(timeout)
        self.sock.connect((self.host, self.port))
        self.sock.settimeout(None)
        self.connected = True
        threading.Thread(target=self._listen, daemon=True).start()
        self._send(f"LOGIN|{self.username}|{self.password}")
        got = self._login_event.wait(timeout=timeout)
        return got and self._login_ok

    def _send(self, text):
        self.sock.sendall((text + "\n").encode("utf-8"))

    def _listen(self):
        while self.connected:
            try:
                chunk = self.sock.recv(4096)
            except OSError:
                break
            if not chunk:
                break
            self._buffer += chunk.decode("utf-8", errors="replace")
            while "\n" in self._buffer:
                line, self._buffer = self._buffer.split("\n", 1)
                line = line.strip()
                if line:
                    self._handle_line(line)
        self.connected = False

    def _handle_line(self, line):
        parts = line.split("|")
        tag = parts[0]
        if tag == "OK" and len(parts) > 1 and parts[1] == "LOGIN_SUCCESS":
            self._login_ok = True
            self._login_event.set()
        elif tag == "ERROR" and not self._login_event.is_set():
            self._login_ok = False
            self._login_event.set()
        elif tag == "OK" and len(parts) > 1 and parts[1] == "MESSAGE_SENT":
            if self._pending_send_time is not None:
                delay = (time.perf_counter() - self._pending_send_time) * 1000.0
                self.latencies.append(delay)
                self._pending_send_time = None
            self._ack_event.set()

    def send_and_wait_ack(self, text, timeout=5.0):
        self._ack_event.clear()
        self._pending_send_time = time.perf_counter()
        try:
            self._send(f"MSG|{text}")
        except OSError:
            self.errors += 1
            return
        if not self._ack_event.wait(timeout=timeout):
            self.errors += 1

    def close(self):
        try:
            self._send("LOGOUT")
        except OSError:
            pass
        self.connected = False
        try:
            self.sock.close()
        except OSError:
            pass


def run_client_worker(host, port, account, messages_per_client, results_bucket, index):
    username, password = account
    client = LoadTestClient(host, port, username, password)
    try:
        ok = client.connect_and_login()
        if not ok:
            results_bucket[index] = {"latencies": [], "errors": messages_per_client}
            return
        for i in range(messages_per_client):
            client.send_and_wait_ack(f"load-test message {i} from worker {index}")
    finally:
        client.close()
    results_bucket[index] = {"latencies": client.latencies, "errors": client.errors}


def sample_server_process(pid, duration, interval=0.5):
    """Samples CPU% and RSS memory of the server process while the test runs."""
    if not psutil or not pid:
        time.sleep(duration)
        return 0.0, 0.0
    try:
        proc = psutil.Process(pid)
    except psutil.NoSuchProcess:
        time.sleep(duration)
        return 0.0, 0.0

    proc.cpu_percent(interval=None)  # prime the counter
    samples_cpu = []
    samples_mem = []
    elapsed = 0.0
    while elapsed < duration:
        time.sleep(interval)
        elapsed += interval
        try:
            samples_cpu.append(proc.cpu_percent(interval=None))
            samples_mem.append(proc.memory_info().rss / (1024 * 1024))
        except psutil.NoSuchProcess:
            break
    avg_cpu = statistics.mean(samples_cpu) if samples_cpu else 0.0
    avg_mem = statistics.mean(samples_mem) if samples_mem else 0.0
    return avg_cpu, avg_mem


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=5000)
    ap.add_argument("--clients", type=int, required=True)
    ap.add_argument("--messages", type=int, default=20)
    ap.add_argument("--label", required=True)
    ap.add_argument("--server-pid", type=int, default=None)
    args = ap.parse_args()

    results_bucket = [None] * args.clients
    threads = []

    # Rough estimate of test duration for CPU/mem sampling window
    estimated_duration = max(3.0, args.messages * 0.05 * 2)

    monitor_result = {}

    def monitor():
        cpu, mem = sample_server_process(args.server_pid, estimated_duration + 2)
        monitor_result["cpu"] = cpu
        monitor_result["mem"] = mem

    monitor_thread = threading.Thread(target=monitor, daemon=True)
    monitor_thread.start()

    start = time.perf_counter()
    for i in range(args.clients):
        account = TEST_ACCOUNTS[i % len(TEST_ACCOUNTS)]
        # Vary username slightly isn't possible (server only knows 3 users),
        # so we round-robin across the 3 known test accounts. The server's
        # duplicate-login prevention means we cap true concurrency at 3 for
        # a given account, so we stagger connections and use LOGOUT between
        # waves when clients > number of accounts.
        t = threading.Thread(target=run_client_worker,
                              args=(args.host, args.port, account, args.messages,
                                    results_bucket, i))
        threads.append(t)

    # Launch in small staggered waves so we don't trip duplicate-login
    # rejection when num_clients > number of distinct test accounts.
    wave_size = len(TEST_ACCOUNTS)
    for wave_start in range(0, len(threads), wave_size):
        wave = threads[wave_start:wave_start + wave_size]
        for t in wave:
            t.start()
        for t in wave:
            t.join()

    total_elapsed = time.perf_counter() - start
    monitor_thread.join(timeout=estimated_duration + 3)

    all_latencies = []
    total_errors = 0
    for r in results_bucket:
        if r:
            all_latencies.extend(r["latencies"])
            total_errors += r["errors"]

    total_messages = len(all_latencies)
    avg_delay = statistics.mean(all_latencies) if all_latencies else 0.0
    p95_delay = (statistics.quantiles(all_latencies, n=20)[18]
                 if len(all_latencies) >= 20 else (max(all_latencies) if all_latencies else 0.0))
    throughput = total_messages / total_elapsed if total_elapsed > 0 else 0.0

    row = {
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
        "label": args.label,
        "num_clients": args.clients,
        "messages_per_client": args.messages,
        "total_messages": total_messages,
        "avg_delay_ms": round(avg_delay, 2),
        "p95_delay_ms": round(p95_delay, 2),
        "throughput_msgs_per_sec": round(throughput, 2),
        "server_cpu_percent": round(monitor_result.get("cpu", 0.0), 2),
        "server_memory_mb": round(monitor_result.get("mem", 0.0), 2),
        "errors": total_errors,
    }

    file_exists = os.path.exists(RESULTS_FILE)
    with open(RESULTS_FILE, "a", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=CSV_HEADER)
        if not file_exists:
            writer.writeheader()
        writer.writerow(row)

    print(f"[RESULT] {row}")


if __name__ == "__main__":
    main()
